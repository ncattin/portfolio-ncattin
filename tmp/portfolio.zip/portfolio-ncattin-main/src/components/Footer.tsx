import { Github, Linkedin, Mail } from "lucide-react";

const Footer = () => {
  return (
    <footer className="border-t border-border bg-card/50">
      <div className="container mx-auto px-4 py-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <p className="font-display font-bold text-lg text-gradient">Nathan Cattin</p>
            <p className="text-sm text-muted-foreground mt-1">Étudiant BTS SIO — SISR</p>
          </div>
          <div className="flex items-center gap-4">
            <a
              href="https://github.com/ncattin"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-lg text-muted-foreground hover:text-primary hover:bg-accent transition-all"
            >
              <Github size={20} />
            </a>
            <a
              href="https://fr.linkedin.com/in/nathan-cattin-4829632a1"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-lg text-muted-foreground hover:text-primary hover:bg-accent transition-all"
            >
              <Linkedin size={20} />
            </a>
            <a
              href="mailto:nathan.cattin31@gmail.com"
              className="p-2 rounded-lg text-muted-foreground hover:text-primary hover:bg-accent transition-all"
            >
              <Mail size={20} />
            </a>
          </div>
          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} Nathan Cattin. Tous droits réservés.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
